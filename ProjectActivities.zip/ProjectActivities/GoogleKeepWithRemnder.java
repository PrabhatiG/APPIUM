package ProjectActivities;

import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

import org.testng.annotations.BeforeClass;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

public class GoogleKeepWithRemnder {
	WebDriverWait wait;
	AppiumDriver<MobileElement> driver= null;
	
	 @BeforeClass
	  public void beforeClass() throws MalformedURLException {
		 //Set desired Capabilities
		  DesiredCapabilities caps=new DesiredCapabilities();
		  caps.setCapability("deviceName", "Pixel_3");
		  caps.setCapability("platformName", "Android");
		  caps.setCapability("appPackage",  "com.google.android.keep");
		  caps.setCapability("appActivity", ".activities.BrowseActivity");
		  caps.setCapability("noReset", true);
		  
		// Instantiate Appium Driver
			 URL appServer=new URL("http://0.0.0.0:4723/wd/hub");
			 driver=new AndroidDriver<MobileElement>(appServer,caps);
			 wait= new WebDriverWait(driver,5);
	  }

  @Test
  public void GoogleNoteWithReminder() throws InterruptedException {
	  
	//Locate the add button and Click it:
	  driver.findElementByAccessibilityId("New text note").click();
	  driver.findElementById("editable_title").click();
	  driver.findElementById("editable_title").sendKeys("Adding new note with reminder");
	 // driver.findElementById("editable_title").click();
	  driver.findElementById("edit_note_text").click();
	  driver.findElementById("edit_note_text").sendKeys("creating reminder");
	  //driver.findElementByAccessibilityId("Single-column view").click();
	  driver.findElementById("com.google.android.keep:id/menu_reminder").click();
	  driver.findElementById("com.google.android.keep:id/time_spinner").click();
	  Thread.sleep(5000L);
	  driver.findElementById("com.google.android.keep:id/reminder_time_afternoon").click();
	  driver.findElementById("com.google.android.keep:id/save").click();
	  
	  driver.findElementByAccessibilityId("Open navigation drawer").click();
	  List<MobileElement> Notes = driver.findElementsById("com.google.android.keep:id/browse_text_note");
		int noOfNotes = Notes.size();
		List<MobileElement> Notestitles =driver.findElementsById("com.google.android.keep:id/index_note_title");
		List<MobileElement> Notesdesc =driver.findElementsById("com.google.android.keep:id/index_note_text_description");
		List<MobileElement> Notereminder =driver.findElementsById("com.google.android.keep:id/reminder_chip_text");
		
		for(int i = 0 ; i<noOfNotes ; i++)
		{
			//driver
			String notetitle = Notestitles.get(i).getText();
			String notedescription = Notesdesc.get(i).getText();
			String Noteremindertext = Notereminder.get(i).getText();
			System.out.println("The current Note Title is :" + notetitle + " and the Description is :" + notedescription + "With Reminder : " + Noteremindertext);
			try {
				Assert.assertEquals(notetitle, "Adding new note with reminder");
				Assert.assertEquals(notedescription, "creating reminder");
				Assert.assertEquals(Noteremindertext,"Today, 1:00 PM");
				System.out.println("The Creted Note is exists with Title as:" + notetitle + " and the Description is :" + notedescription + "With Reminder : " + Noteremindertext);
				break;
			}
			catch(Exception e) {
				System.out.println("The Created Note is not exists");
			}
		}
  }
 
  @AfterClass
  public void afterClass() {
	  driver.close();
  }

}
