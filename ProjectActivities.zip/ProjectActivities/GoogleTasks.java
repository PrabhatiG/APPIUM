package ProjectActivities;

import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

import org.testng.annotations.BeforeClass;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

public class GoogleTasks {
	WebDriverWait wait;
	AppiumDriver<MobileElement> driver= null;
	
  @BeforeClass
  public void beforeClass() throws MalformedURLException {
	  //Set desired Capabilities
	  DesiredCapabilities caps=new DesiredCapabilities();
	  caps.setCapability("deviceName", "Pixel_3");
	  caps.setCapability("platformName", "Android");
	  caps.setCapability("appPackage", "com.google.android.apps.tasks");
	  caps.setCapability("appActivity", ".ui.TaskListsActivity");
	  caps.setCapability("noReset", true);
	  
	// Instantiate Appium Driver
	  URL appServer=new URL("http://0.0.0.0:4723/wd/hub");
	  driver= new AndroidDriver<MobileElement>(appServer,caps);
	
	  }
 @Test
  public void GoogleTasks() {
	 //Add tasks and save in Google Tasks:
	 ArrayList<String> taskLists = new ArrayList<String>();
		taskLists.add("Complete Activity with Google Tasks");
		taskLists.add("Complete Activity with Google Keep");
		taskLists.add("Complete the second Activity Google Keep");

		for (String taskList : taskLists) {

			driver.findElementByAccessibilityId("Create new task").click();

			wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.presenceOfElementLocated(MobileBy.id("add_task_title")));

			driver.findElementById("add_task_title").sendKeys(taskList);

			driver.findElementById("add_task_done").click();

			List<MobileElement> taskNames = driver
					.findElementsByXPath("//android.widget.TextView[@text='" + taskList + "']");

			for (MobileElement taskName : taskNames) {

				Assert.assertEquals(taskName.getText(), taskList);
			}

		}

	}
     
 
  @AfterClass
  public void afterClass() {
	  driver.quit();
  }

}
