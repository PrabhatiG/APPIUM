package ProjectActivities;

import org.testng.annotations.Test;

import com.google.common.collect.ImmutableMap;
import com.google.errorprone.annotations.Immutable;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

import org.testng.annotations.BeforeClass;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

public class GoogleToDoList {
	AppiumDriver<MobileElement> driver=null;
	WebDriverWait wait;
	
	@BeforeClass
 public void beforeClass() throws MalformedURLException {
		//Set Desired capabilities
		DesiredCapabilities caps=new DesiredCapabilities();
		caps.setCapability("deviceName", "Pixel_3");
		caps.setCapability("platformName","Android");
		caps.setCapability("appPackage", "com.android.chrome");
		caps.setCapability("appActivity", "com.google.android.apps.chrome.Main");
		caps.setCapability("noReset", true);
		
		// Instantiate Appium Driver
		//URL appServer=new URL("http://0.0.0.0:4723/wd/hub");
		//driver=new AndroidDriver<MobileElement>(appServer,caps);
		//wait=new WebDriverWait(driver,5);
		URL appServer=new URL("http://0.0.0.0:4723/wd/hub");
		driver=new AndroidDriver<MobileElement>(appServer,caps);
		wait=new WebDriverWait(driver,10);
		driver.get("https://www.training-support.net/selenium");
	  }

  @Test
  public void GoogleToDoList() throws InterruptedException {
	  Thread.sleep(5000L);
	
	  //driver.findElement(MobileBy.AndroidUIAutomator("UiScrollable(UiSelector().scrollable(true).instance(0)).scrollForward().scrollIntoView(textContains(\"To-Do List\"))")).click();
	  /*
    TouchAction act=new TouchAction(driver);
    Dimension d=driver.manage().window().getSize();
    int width=d.width;
    int height=d.height;
    int x1=width/2;
    int y1=4*height/5;
    int x2=width/2;
    int y2=height/5;
    
    while(driver.findElements(MobileBy.AndroidUIAutomator("UiSelector().text(\"To-Do List  Elements get added at run time\n" + 
    		"\")")).size()==0) {
    	
    	act.press(PointOption.point(x1,y1)).waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1))).moveTo(PointOption.point(x2,y2)).release().perform();
   
    	//driver.executeScript("mobile:shell", ImmutableMap.of("command","inputswipe"+x1+""+y1+""+x2+""+y2));
    	
    	
    	driver.findElementByXPath("//android.webkit.WebView/android.view.View[2]/android.view.View[3]/android.view.View[15]/android.view.View").click();
    }
    
	   */
	  driver.findElement(MobileBy.AndroidUIAutomator(
				"new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\"To-Do List\").instance(0))"));

		driver.findElementByXPath("//android.widget.TextView[@text='To-Do List']").click();

		wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.presenceOfElementLocated(MobileBy.xpath("//android.widget.EditText[@text='']")));

		ArrayList<String> taskLists = new ArrayList<String>();
		taskLists.add("Add tasks to list");
		taskLists.add("Get number of tasks");
		taskLists.add("Clear the list");

		for (String tasklist : taskLists) {

			driver.findElementByXPath("//android.widget.EditText[@text='']").click();
			driver.findElementByXPath("//android.widget.EditText[@text='']").sendKeys(tasklist);

			driver.findElementByXPath("//android.widget.Button[@text='Add Task']").click();

			List<MobileElement> taskNames = driver.findElementsByXPath("//android.view.View[@text='" + tasklist + "']");

			for (MobileElement taskName : taskNames) {

				Assert.assertEquals(taskName.getText(), tasklist);

				taskName.click();

			}

		}

		driver.findElementByXPath("//android.view.View[@text='']").click();

	}
 
  @AfterClass
  public void afterClass() {
	  driver.quit();
  }

}
